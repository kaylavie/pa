<?php
defined( 'ABSPATH' ) || exit;

class PA_DB {

    public static function install() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Sessions table
        dbDelta( "CREATE TABLE {$wpdb->prefix}pa_sessions (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id    VARCHAR(64)  NOT NULL,
            user_id       BIGINT UNSIGNED DEFAULT NULL,
            started_at    DATETIME     NOT NULL,
            ended_at      DATETIME     DEFAULT NULL,
            entry_screen  VARCHAR(255) DEFAULT NULL,
            status        VARCHAR(20)  NOT NULL DEFAULT 'active',
            PRIMARY KEY (id),
            UNIQUE KEY session_id (session_id),
            KEY user_id (user_id)
        ) $charset;" );

        // Events table
        dbDelta( "CREATE TABLE {$wpdb->prefix}pa_events (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id   VARCHAR(64)  NOT NULL,
            event_type   VARCHAR(50)  NOT NULL,
            screen       VARCHAR(255) DEFAULT NULL,
            element_tag  VARCHAR(50)  DEFAULT NULL,
            element_id   VARCHAR(255) DEFAULT NULL,
            element_text VARCHAR(255) DEFAULT NULL,
            aria_label   VARCHAR(255) DEFAULT NULL,
            selector     VARCHAR(255) DEFAULT NULL,
            viewport_w   SMALLINT UNSIGNED DEFAULT NULL,
            viewport_h   SMALLINT UNSIGNED DEFAULT NULL,
            scroll_depth SMALLINT UNSIGNED DEFAULT NULL,
            meta         LONGTEXT     DEFAULT NULL,
            occurred_at  BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY event_type (event_type),
            KEY screen (screen)
        ) $charset;" );

        // Markers table — pain / confused / success / finish
        dbDelta( "CREATE TABLE {$wpdb->prefix}pa_markers (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id    VARCHAR(64)  NOT NULL,
            marker_type   VARCHAR(20)  NOT NULL,
            annotation    TEXT         DEFAULT NULL,
            screen        VARCHAR(255) DEFAULT NULL,
            screenshot_id BIGINT UNSIGNED DEFAULT NULL,
            event_buffer  LONGTEXT     DEFAULT NULL,
            occurred_at   BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY marker_type (marker_type)
        ) $charset;" );

        // Screenshots table
        dbDelta( "CREATE TABLE {$wpdb->prefix}pa_screenshots (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id  VARCHAR(64)  NOT NULL,
            marker_id   BIGINT UNSIGNED DEFAULT NULL,
            file_path   VARCHAR(512) NOT NULL,
            file_size   INT UNSIGNED DEFAULT NULL,
            captured_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY session_id (session_id)
        ) $charset;" );

        // Reports table
        dbDelta( "CREATE TABLE {$wpdb->prefix}pa_reports (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id   VARCHAR(64)  NOT NULL,
            generated_at DATETIME     NOT NULL,
            issues       LONGTEXT     DEFAULT NULL,
            raw_ai       LONGTEXT     DEFAULT NULL,
            status       VARCHAR(20)  NOT NULL DEFAULT 'pending',
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY status (status)
        ) $charset;" );

        update_option( 'pa_db_version', PA_VERSION );
    }

    public static function deactivate() {
        // Intentionally non-destructive on deactivation.
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    public static function insert_event( array $data ) {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'pa_events', $data );
        return $wpdb->insert_id;
    }

    public static function insert_marker( array $data ) {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'pa_markers', $data );
        return $wpdb->insert_id;
    }

    public static function insert_screenshot( array $data ) {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'pa_screenshots', $data );
        return $wpdb->insert_id;
    }

    public static function get_session( $session_id ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}pa_sessions WHERE session_id = %s",
                $session_id
            )
        );
    }

    public static function get_sessions( $args = array() ) {
        global $wpdb;
        $limit  = isset( $args['limit'] )  ? intval( $args['limit'] )  : 50;
        $offset = isset( $args['offset'] ) ? intval( $args['offset'] ) : 0;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT s.*,
                    COUNT(DISTINCT e.id) AS event_count,
                    COUNT(DISTINCT m.id) AS marker_count
                FROM {$wpdb->prefix}pa_sessions s
                LEFT JOIN {$wpdb->prefix}pa_events  e ON e.session_id = s.session_id
                LEFT JOIN {$wpdb->prefix}pa_markers m ON m.session_id = s.session_id
                GROUP BY s.id
                ORDER BY s.started_at DESC
                LIMIT %d OFFSET %d",
                $limit,
                $offset
            )
        );
    }

    public static function get_session_events( $session_id ) {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}pa_events
                 WHERE session_id = %s
                 ORDER BY occurred_at ASC",
                $session_id
            )
        );
    }

    public static function get_session_markers( $session_id ) {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT m.*, s.file_path AS screenshot_path
                 FROM {$wpdb->prefix}pa_markers m
                 LEFT JOIN {$wpdb->prefix}pa_screenshots s ON s.marker_id = m.id
                 WHERE m.session_id = %s
                 ORDER BY m.occurred_at ASC",
                $session_id
            )
        );
    }

    public static function get_session_screenshots( $session_id ) {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}pa_screenshots
                 WHERE session_id = %s
                 ORDER BY captured_at ASC",
                $session_id
            )
        );
    }

    public static function get_report( $session_id ) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}pa_reports WHERE session_id = %s ORDER BY id DESC LIMIT 1",
                $session_id
            )
        );
    }

    public static function upsert_report( $session_id, array $data ) {
        global $wpdb;
        $existing = self::get_report( $session_id );
        if ( $existing ) {
            $wpdb->update(
                $wpdb->prefix . 'pa_reports',
                $data,
                array( 'id' => $existing->id )
            );
        } else {
            $data['session_id']   = $session_id;
            $data['generated_at'] = current_time( 'mysql' );
            $wpdb->insert( $wpdb->prefix . 'pa_reports', $data );
        }
    }

    public static function end_session( $session_id ) {
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'pa_sessions',
            array( 'ended_at' => current_time( 'mysql' ), 'status' => 'completed' ),
            array( 'session_id' => $session_id )
        );
    }
}
