<?php
defined( 'ABSPATH' ) || exit;

class PA_Session {

    private static $session_id = null;

    const OPT_ACTIVE_ID = 'pa_active_session_id';

    public static function init() {
        // Resolve the active session id (if any) early so other components can read it.
        add_action( 'init', array( __CLASS__, 'resolve_active' ), 5 );
    }

    /**
     * Read the currently-active session id (set by PA_Test_Runner on Start)
     * and cache it on the class for cheap access during the rest of the request.
     *
     * A session row is created ONLY by PA_Test_Runner::ajax_start_test().
     * Nothing in this class spawns sessions any more — that was the source of
     * the duplicate-session bug, where every admin page load could mint a new row.
     */
    public static function resolve_active() {
        $id = get_option( self::OPT_ACTIVE_ID, '' );
        if ( ! $id ) {
            self::$session_id = null;
            return;
        }
        $row = PA_DB::get_session( $id );
        if ( $row && $row->status === 'active' ) {
            self::$session_id = $id;
        } else {
            // Stale pointer — clear it so we don't keep referring to a closed session.
            delete_option( self::OPT_ACTIVE_ID );
            self::$session_id = null;
        }
    }

    /**
     * Create one new session row and mark it active.
     * Called only by the test runner on Start.
     */
    public static function start_new() {
        $session_id = wp_generate_uuid4();

        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'pa_sessions',
            array(
                'session_id'   => $session_id,
                'user_id'      => get_current_user_id(),
                'started_at'   => current_time( 'mysql' ),
                'entry_screen' => isset( $_SERVER['REQUEST_URI'] )
                    ? sanitize_text_field( $_SERVER['REQUEST_URI'] )
                    : '',
                'status'       => 'active',
            )
        );

        update_option( self::OPT_ACTIVE_ID, $session_id, false );
        self::$session_id = $session_id;
        return $session_id;
    }

    public static function clear_active() {
        delete_option( self::OPT_ACTIVE_ID );
        self::$session_id = null;
    }

    public static function get_id() {
        // If something asks before our resolver ran, resolve on demand.
        if ( self::$session_id === null ) {
            self::resolve_active();
        }
        return self::$session_id;
    }
}
