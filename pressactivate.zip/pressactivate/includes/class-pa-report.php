<?php
defined( 'ABSPATH' ) || exit;

/**
 * PA_Report
 *
 * Builds a report.v1 payload from a completed session. Used in two places:
 *   - "Download raw report" button on the per-session report page (this class
 *     handles the admin_post download endpoint directly).
 *   - Future: "Generate web report" upload to pressactivate.com (this class
 *     will produce the same payload; the upload is a separate concern).
 *
 * The payload shape is defined by schema/report.v1.json in the repo root.
 * Any change to that schema must be reflected here.
 */
class PA_Report {

    const SCHEMA_VERSION = '1.0';

    public static function init() {
        add_action( 'admin_post_pa_download_report', array( __CLASS__, 'handle_download' ) );
    }

    /**
     * Build the report payload for a session.
     *
     * Returns an array shaped to match schema/report.v1.json. The screenshots[]
     * entries contain base64-encoded image data; capped at 20 per the schema.
     */
    public static function build( $session_id ) {
        $session  = PA_DB::get_session( $session_id );
        if ( ! $session ) {
            return null;
        }

        $events     = PA_DB::get_session_events( $session_id );
        $markers    = PA_DB::get_session_markers( $session_id );
        $blueprint  = PA_Test_Runner::get_blueprint();
        $state      = PA_Test_Runner::get_state();

        // Idempotency: a stable report_id per session means re-downloading
        // produces the same id, and a future upload-to-API call won't duplicate.
        $report_id = self::stable_report_id( $session_id );

        $started_ts = strtotime( $session->started_at );
        $ended_ts   = ! empty( $session->ended_at ) ? strtotime( $session->ended_at ) : time();
        $duration   = max( 0, $ended_ts - $started_ts );

        $payload = array(
            'schema_version' => self::SCHEMA_VERSION,
            'report_id'      => $report_id,
            'generated_at'   => gmdate( 'c' ),
            'auth_token'     => null,
            'plugin'         => array(
                'name'    => 'PressActivate',
                'version' => defined( 'PA_VERSION' ) ? PA_VERSION : '0.0.0',
            ),
            'test'           => self::build_test_block( $blueprint ),
            'session'        => array(
                'started_at'       => gmdate( 'c', $started_ts ),
                'ended_at'         => gmdate( 'c', $ended_ts ),
                'duration_seconds' => $duration,
                'entry_screen'     => $session->entry_screen ?: null,
            ),
            'environment'    => self::build_environment_block(),
            'tasks'          => self::build_tasks_block( $blueprint, $state ),
            'events'         => self::shape_events( $events ),
            'markers'        => self::shape_markers( $markers ),
        );

        // Screenshots: capped + pruned. Returns array + count dropped.
        list( $shots, $dropped ) = self::build_screenshots_block( $session_id, $markers, $events );
        $payload['screenshots'] = $shots;
        $payload['pruning'] = array(
            'screenshots_dropped' => $dropped,
            'events_dropped'      => 0,
        );

        return $payload;
    }

    private static function stable_report_id( $session_id ) {
        // Deterministic UUIDv4-shaped id derived from the session id, so
        // re-downloading the same session produces the same report_id.
        $hash = md5( 'pa-report:' . $session_id );
        return sprintf(
            '%s-%s-4%s-%s%s-%s',
            substr( $hash, 0,  8 ),
            substr( $hash, 8,  4 ),
            substr( $hash, 13, 3 ),
            dechex( hexdec( substr( $hash, 16, 1 ) ) & 0x3 | 0x8 ),
            substr( $hash, 17, 3 ),
            substr( $hash, 20, 12 )
        );
    }

    private static function build_test_block( $blueprint ) {
        if ( ! $blueprint ) {
            // Session existed without a blueprint — emit minimal fields, but
            // schema requires session_name and blueprint_hash, so produce
            // a synthetic hash of empty input.
            return array(
                'session_name'              => 'Untitled session',
                'plugin_under_test'         => null,
                'blueprint_hash'            => hash( 'sha256', '' ),
                'estimated_duration_minutes'=> null,
            );
        }

        // Canonical JSON: re-encode with sorted keys so the same blueprint
        // always hashes identically regardless of original key order.
        $canonical = wp_json_encode( self::ksort_recursive( $blueprint ) );

        return array(
            'session_name'              => $blueprint['session_name'] ?? 'Untitled session',
            'plugin_under_test'         => $blueprint['plugin_name']   ?? null,
            'blueprint_hash'            => hash( 'sha256', (string) $canonical ),
            'estimated_duration_minutes'=> isset( $blueprint['estimated_duration_minutes'] )
                ? intval( $blueprint['estimated_duration_minutes'] )
                : null,
        );
    }

    private static function ksort_recursive( $arr ) {
        if ( ! is_array( $arr ) ) {
            return $arr;
        }
        $out = array();
        $keys = array_keys( $arr );
        sort( $keys );
        foreach ( $keys as $k ) {
            $out[ $k ] = self::ksort_recursive( $arr[ $k ] );
        }
        return $out;
    }

    private static function build_environment_block() {
        global $wp_version;
        return array(
            'wp_version'    => $wp_version,
            'php_version'   => PHP_VERSION,
            'user_agent'    => isset( $_SERVER['HTTP_USER_AGENT'] )
                ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 500 )
                : null,
            // Viewport isn't known server-side; capture.js could send it in a
            // future revision. For v1 we omit dimensions.
            'viewport'      => array( 'w' => 0, 'h' => 0 ),
            'is_playground' => self::detect_playground(),
        );
    }

    private static function detect_playground() {
        // Playground sets a recognizable hostname; we can also sniff the user
        // agent. This is best-effort — false negatives are harmless.
        $host = $_SERVER['HTTP_HOST'] ?? '';
        if ( stripos( $host, 'playground.wordpress.net' ) !== false ) {
            return true;
        }
        if ( defined( 'WP_PLAYGROUND' ) && WP_PLAYGROUND ) {
            return true;
        }
        return false;
    }

    private static function build_tasks_block( $blueprint, $state ) {
        if ( ! $blueprint || empty( $blueprint['tasks'] ) ) {
            return array();
        }

        $current_idx = intval( $state['current_task'] ?? 0 );
        $ended       = ( $state['status'] ?? '' ) === 'ended';

        $out = array();
        foreach ( $blueprint['tasks'] as $i => $t ) {
            // A task is "completed" if the test ran past it. The current task
            // counts as completed only if the test ended.
            $completed = ( $i < $current_idx ) || ( $i === $current_idx && $ended );

            $out[] = array(
                'id'               => $t['id']    ?? 'task_' . $i,
                'title'            => $t['title'] ?? 'Untitled task',
                'category'         => $t['category'] ?? null,
                'completed'        => (bool) $completed,
                'duration_seconds' => null,         // not tracked yet per-task
                'started_at'       => null,
                'ended_at'         => null,
                'answers'          => new \stdClass(), // empty object, not array
            );
        }
        return $out;
    }

    private static function shape_events( $events ) {
        if ( ! $events ) {
            return array();
        }
        $out = array();
        foreach ( $events as $e ) {
            $meta = json_decode( $e->meta ?? '{}', true );
            $meta = is_array( $meta ) ? $meta : array();

            $out[] = array(
                't'               => isset( $e->occurred_at ) ? intval( $e->occurred_at ) : 0,
                'type'            => $e->event_type ?? 'click',
                'url'             => $e->screen ?? null,
                'target_text'     => isset( $e->element_text ) ? substr( (string) $e->element_text, 0, 120 ) : null,
                'target_selector' => isset( $e->selector )     ? (string) $e->selector : null,
                'meta'            => $meta,
            );
        }
        return $out;
    }

    private static function shape_markers( $markers ) {
        if ( ! $markers ) {
            return array();
        }
        $out = array();
        foreach ( $markers as $m ) {
            $out[] = array(
                'id'              => 'marker_' . $m->id,
                'type'            => $m->marker_type ?? 'pain',
                't'               => isset( $m->occurred_at ) ? intval( $m->occurred_at ) : 0,
                'url'             => $m->screen ?? null,
                'task_id'         => null,
                'screenshot_id'   => ! empty( $m->screenshot_id ) ? 'shot_' . $m->screenshot_id : null,
                // Taxonomy tagging lands when PA_Taxonomy ships; for now, null.
                'taxonomy_slug'   => isset( $m->taxonomy_slug ) ? $m->taxonomy_slug : null,
                'suggested_slugs' => array(),
                'note'            => isset( $m->annotation ) ? $m->annotation : null,
            );
        }
        return $out;
    }

    /**
     * Build the screenshots block. Caps at 20 with deterministic pruning per
     * schema rules:
     *   (a) marker-with-taxonomy → (b) any marker → (c) everything else, oldest first
     * Tiebreak inside each tier: ascending timestamp.
     *
     * Note: the current DB schema doesn't record a URL or dimensions per
     * screenshot, so the "first-of-URL" tier from the schema docs isn't
     * implementable here. When capture.js starts recording per-shot URL,
     * extend the ranking to honor it.
     */
    private static function build_screenshots_block( $session_id, $markers, $events ) {
        $all_shots = PA_DB::get_session_screenshots( $session_id );
        if ( ! $all_shots ) {
            return array( array(), 0 );
        }

        // Map of marker_id → marker, and which screenshots have a tagged marker.
        $marker_with_tax_ids = array();
        $marker_any_ids      = array();
        $shot_id_to_marker   = array();
        foreach ( $markers as $m ) {
            if ( ! empty( $m->screenshot_id ) ) {
                $marker_any_ids[ $m->screenshot_id ] = true;
                if ( ! empty( $m->taxonomy_slug ) ) {
                    $marker_with_tax_ids[ $m->screenshot_id ] = true;
                }
                $shot_id_to_marker[ $m->screenshot_id ] = $m->id;
            }
        }

        $ranked = array();
        foreach ( $all_shots as $s ) {
            $tier = 3;
            if ( isset( $marker_with_tax_ids[ $s->id ] ) )      $tier = 1;
            elseif ( isset( $marker_any_ids[ $s->id ] ) )       $tier = 2;
            $ranked[] = array(
                'tier' => $tier,
                'ts'   => intval( $s->captured_at ?? 0 ),
                's'    => $s,
            );
        }

        usort( $ranked, function( $a, $b ) {
            if ( $a['tier'] !== $b['tier'] ) return $a['tier'] - $b['tier'];
            return $a['ts'] - $b['ts'];
        } );

        $kept_max = 20;
        $kept = array_slice( $ranked, 0, $kept_max );
        $dropped = max( 0, count( $ranked ) - count( $kept ) );

        $out = array();
        foreach ( $kept as $entry ) {
            $s = $entry['s'];
            $bytes = self::read_screenshot_bytes( $s );
            if ( $bytes === null ) continue;

            $marker_id = isset( $shot_id_to_marker[ $s->id ] )
                ? 'marker_' . $shot_id_to_marker[ $s->id ]
                : null;

            $out[] = array(
                'id'          => 'shot_' . $s->id,
                'format'      => 'jpeg',
                'width'       => null,   // not currently captured
                'height'      => null,   // not currently captured
                'marker_id'   => $marker_id,
                'data_base64' => base64_encode( $bytes ),
            );
        }

        return array( $out, $dropped );
    }

    private static function read_screenshot_bytes( $screenshot ) {
        if ( empty( $screenshot->file_path ) ) {
            return null;
        }
        $upload_dir = wp_upload_dir();
        $full = trailingslashit( $upload_dir['basedir'] ) . ltrim( $screenshot->file_path, '/' );
        if ( ! file_exists( $full ) ) {
            return null;
        }
        return @file_get_contents( $full );
    }

    /**
     * admin_post_pa_download_report handler.
     * URL: admin-post.php?action=pa_download_report&session_id=...&_wpnonce=...
     */
    public static function handle_download() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized', 403 );
        }
        $session_id = sanitize_text_field( $_GET['session_id'] ?? '' );
        if ( ! $session_id ) {
            wp_die( 'Missing session_id', 400 );
        }
        check_admin_referer( 'pa_download_report_' . $session_id );

        $payload = self::build( $session_id );
        if ( ! $payload ) {
            wp_die( 'Session not found', 404 );
        }

        $filename = 'pressactivate-report-' . substr( $session_id, 0, 8 ) . '.json';

        nocache_headers();
        header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

        echo wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        exit;
    }
}
