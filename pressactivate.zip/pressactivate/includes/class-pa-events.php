<?php
defined( 'ABSPATH' ) || exit;

class PA_Events {

    public static function init() {
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
        add_action( 'wp_ajax_pa_store_events',  array( __CLASS__, 'ajax_store_events' ) );
        add_action( 'wp_ajax_pa_store_marker',  array( __CLASS__, 'ajax_store_marker' ) );
        add_action( 'wp_ajax_pa_end_session',   array( __CLASS__, 'ajax_end_session' ) );
    }

    public static function enqueue() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $session_id = PA_Session::get_id();
        if ( ! $session_id ) {
            return;
        }

        wp_enqueue_script(
            'pa-capture',
            PA_PLUGIN_URL . 'assets/js/capture.js',
            array(),
            PA_VERSION,
            true
        );

        // html2canvas from CDN
        wp_enqueue_script(
            'html2canvas',
            'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js',
            array(),
            '1.4.1',
            true
        );

        wp_enqueue_style(
            'pa-overlay',
            PA_PLUGIN_URL . 'assets/css/overlay.css',
            array(),
            PA_VERSION
        );

        // Current screen context
        $screen      = get_current_screen();
        $screen_id   = $screen ? $screen->id   : '';
        $screen_base = $screen ? $screen->base  : '';

        wp_localize_script( 'pa-capture', 'PA', array(
            'ajaxurl'    => admin_url( 'admin-ajax.php' ),
            'nonce'      => wp_create_nonce( 'pa_nonce' ),
            'session_id' => $session_id,
            'screen'     => array(
                'id'      => $screen_id,
                'base'    => $screen_base,
                'url'     => isset( $_SERVER['REQUEST_URI'] )
                    ? sanitize_text_field( $_SERVER['REQUEST_URI'] )
                    : '',
            ),
            'flush_interval' => 10000, // ms between auto-flushes
            'buffer_limit'   => 50,
        ) );
    }

    // ── AJAX: store batched events ────────────────────────────────────────

    public static function ajax_store_events() {
        check_ajax_referer( 'pa_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $session_id = sanitize_text_field( wp_unslash( $_POST['session_id'] ?? '' ) );
        $events_raw = wp_unslash( $_POST['events'] ?? '' );

        if ( ! $session_id || ! $events_raw ) {
            wp_send_json_error( 'Missing data' );
        }

        $events = json_decode( $events_raw, true );
        if ( ! is_array( $events ) ) {
            wp_send_json_error( 'Invalid JSON' );
        }

        $allowed_types = array(
            'click', 'page_load', 'search', 'plugin_install',
            'plugin_activate', 'menu_open', 'form_submit',
            'ajax_error', 'scroll',
        );

        foreach ( $events as $e ) {
            $type = sanitize_key( $e['event_type'] ?? '' );
            if ( ! in_array( $type, $allowed_types, true ) ) {
                continue;
            }

            PA_DB::insert_event( array(
                'session_id'   => $session_id,
                'event_type'   => $type,
                'screen'       => sanitize_text_field( $e['screen']       ?? '' ),
                'element_tag'  => sanitize_text_field( $e['element_tag']  ?? '' ),
                'element_id'   => sanitize_text_field( $e['element_id']   ?? '' ),
                'element_text' => sanitize_text_field( substr( $e['element_text'] ?? '', 0, 255 ) ),
                'aria_label'   => sanitize_text_field( $e['aria_label']   ?? '' ),
                'selector'     => sanitize_text_field( $e['selector']     ?? '' ),
                'viewport_w'   => intval( $e['viewport_w'] ?? 0 ),
                'viewport_h'   => intval( $e['viewport_h'] ?? 0 ),
                'scroll_depth' => intval( $e['scroll_depth'] ?? 0 ),
                'meta'         => wp_json_encode( $e['meta'] ?? array() ),
                'occurred_at'  => intval( $e['timestamp'] ?? time() * 1000 ),
            ) );
        }

        wp_send_json_success();
    }

    // ── AJAX: store pain/confused/success/finish marker ───────────────────

    public static function ajax_store_marker() {
        check_ajax_referer( 'pa_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $session_id   = sanitize_text_field( wp_unslash( $_POST['session_id']   ?? '' ) );
        $marker_type  = sanitize_key(         wp_unslash( $_POST['marker_type']  ?? '' ) );
        $annotation   = sanitize_textarea_field( wp_unslash( $_POST['annotation'] ?? '' ) );
        $screen       = sanitize_text_field( wp_unslash( $_POST['screen']        ?? '' ) );
        $event_buffer = wp_unslash( $_POST['event_buffer'] ?? '' );

        $allowed_markers = array( 'pain', 'confused', 'success', 'finish' );
        if ( ! in_array( $marker_type, $allowed_markers, true ) ) {
            wp_send_json_error( 'Invalid marker type' );
        }

        $marker_id = PA_DB::insert_marker( array(
            'session_id'   => $session_id,
            'marker_type'  => $marker_type,
            'annotation'   => $annotation,
            'screen'       => $screen,
            'event_buffer' => $event_buffer,
            'occurred_at'  => time() * 1000,
        ) );

        if ( $marker_type === 'finish' ) {
            PA_DB::end_session( $session_id );
        }

        wp_send_json_success( array( 'marker_id' => $marker_id ) );
    }

    // ── AJAX: end session ─────────────────────────────────────────────────

    public static function ajax_end_session() {
        check_ajax_referer( 'pa_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }
        $session_id = sanitize_text_field( wp_unslash( $_POST['session_id'] ?? '' ) );
        PA_DB::end_session( $session_id );
        wp_send_json_success();
    }
}
