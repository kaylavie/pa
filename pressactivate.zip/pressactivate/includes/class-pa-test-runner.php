<?php
defined( 'ABSPATH' ) || exit;

/**
 * PA_Test_Runner
 *
 * Handles the user-testing workflow added in v1.1:
 *   - On plugin activation, set a flag so we can redirect to the User Test page.
 *   - Provide a "User Test" admin page where the operator uploads a JSON blueprint
 *     describing the test (tasks, questions, etc), reads instructions, and
 *     clicks Start / End to bookend a test run.
 *   - Render a persistent floating card in the bottom-right of every page
 *     (admin + frontend) showing the test status, current task, and
 *     start/end controls.
 *   - Persist test state and blueprint as WP options so they survive
 *     across page loads.
 */
class PA_Test_Runner {

    const OPT_BLUEPRINT      = 'pa_test_blueprint';
    const OPT_STATE          = 'pa_test_state';
    const OPT_REDIRECT_FLAG  = 'pa_do_activation_redirect';

    public static function init() {
        // Activation redirect.
        add_action( 'admin_init', array( __CLASS__, 'maybe_redirect_after_activation' ) );

        // Admin page + assets.
        add_action( 'admin_menu',            array( __CLASS__, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin' ) );

        // Floating card on every page — admin AND frontend.
        add_action( 'admin_footer', array( __CLASS__, 'render_floating_card' ) );
        add_action( 'wp_footer',    array( __CLASS__, 'render_floating_card' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_frontend' ) );

        // AJAX endpoints — available on frontend AND admin.
        add_action( 'wp_ajax_pa_upload_blueprint', array( __CLASS__, 'ajax_upload_blueprint' ) );
        add_action( 'wp_ajax_pa_start_test',       array( __CLASS__, 'ajax_start_test' ) );
        add_action( 'wp_ajax_pa_end_test',         array( __CLASS__, 'ajax_end_test' ) );
        add_action( 'wp_ajax_pa_get_test_state',   array( __CLASS__, 'ajax_get_test_state' ) );
        add_action( 'wp_ajax_pa_advance_task',     array( __CLASS__, 'ajax_advance_task' ) );
    }

    // ── Activation ────────────────────────────────────────────────────────

    public static function on_activate() {
        // Drop a flag; the next admin pageload will see it and redirect.
        // We don't redirect from inside the activation hook itself because WP
        // is mid-request and headers may already have been sent.
        update_option( self::OPT_REDIRECT_FLAG, '1' );

        // Seed empty state.
        if ( ! get_option( self::OPT_STATE ) ) {
            update_option( self::OPT_STATE, wp_json_encode( array(
                'status'         => 'idle', // idle | running | ended
                'current_task'   => 0,
                'started_at'     => null,
                'ended_at'       => null,
                'session_id'     => null,
            ) ) );
        }
    }

    public static function maybe_redirect_after_activation() {
        if ( ! get_option( self::OPT_REDIRECT_FLAG ) ) {
            return;
        }
        // One-shot.
        delete_option( self::OPT_REDIRECT_FLAG );

        // Don't redirect during bulk-activation or AJAX.
        if ( wp_doing_ajax() || isset( $_GET['activate-multi'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=pa-user-test' ) );
        exit;
    }

    // ── Admin menu / page ─────────────────────────────────────────────────

    public static function register_menu() {
        add_submenu_page(
            'pressactivate',
            'User Test',
            'User Test',
            'manage_options',
            'pa-user-test',
            array( __CLASS__, 'page_user_test' )
        );
    }

    public static function enqueue_admin( $hook ) {
        // Floating card needs its assets everywhere in admin, not just our page.
        wp_enqueue_style(
            'pa-test-card',
            PA_PLUGIN_URL . 'assets/css/test-card.css',
            array(),
            PA_VERSION
        );

        wp_enqueue_script(
            'pa-test-card',
            PA_PLUGIN_URL . 'assets/js/test-card.js',
            array(),
            PA_VERSION,
            true
        );

        wp_localize_script( 'pa-test-card', 'PA_TEST', array(
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'pa_test_nonce' ),
            'context' => 'admin',
        ) );

        // Page-specific styles for the upload UI.
        if ( strpos( (string) $hook, 'pa-user-test' ) !== false ) {
            wp_enqueue_style(
                'pa-test-page',
                PA_PLUGIN_URL . 'assets/css/test-page.css',
                array(),
                PA_VERSION
            );
            wp_enqueue_script(
                'pa-test-page',
                PA_PLUGIN_URL . 'assets/js/test-page.js',
                array( 'pa-test-card' ),
                PA_VERSION,
                true
            );
        }
    }

    public static function enqueue_frontend() {
        // Only show the floating card on the frontend to users who can run tests.
        // Without this gate, anonymous visitors would see the card too.
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        wp_enqueue_style(
            'pa-test-card',
            PA_PLUGIN_URL . 'assets/css/test-card.css',
            array(),
            PA_VERSION
        );
        wp_enqueue_script(
            'pa-test-card',
            PA_PLUGIN_URL . 'assets/js/test-card.js',
            array(),
            PA_VERSION,
            true
        );
        wp_localize_script( 'pa-test-card', 'PA_TEST', array(
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'pa_test_nonce' ),
            'context' => 'frontend',
        ) );
    }

    // ── Admin page ─────────────────────────────────────────────────────────

    public static function page_user_test() {
        $blueprint = self::get_blueprint();
        $state     = self::get_state();
        ?>
        <div class="wrap pa-wrap">
            <div class="pa-header">
                <h1>User Test</h1>
                <p class="pa-sub">Upload a test blueprint, then run a moderated or self-guided session.</p>
            </div>

            <div class="pa-test-grid">

                <!-- Upload column -->
                <div class="pa-test-col">
                    <div class="pa-card">
                        <div class="pa-card-title">1. Upload test blueprint</div>
                        <p class="pa-card-desc">
                            Upload a JSON file describing the test — tasks, success URLs, and post-task questions.
                            The current blueprint will be replaced.
                        </p>

                        <div id="pa-dropzone" class="pa-dropzone">
                            <input type="file" id="pa-bp-file" accept="application/json,.json" hidden />
                            <div class="pa-dropzone-inner">
                                <div class="pa-dropzone-icon">⬆</div>
                                <div class="pa-dropzone-text">
                                    <strong>Drop JSON file here</strong>
                                    <span>or click to browse</span>
                                </div>
                            </div>
                        </div>

                        <div id="pa-upload-feedback" class="pa-upload-feedback" hidden></div>

                        <?php if ( $blueprint ) : ?>
                            <div class="pa-blueprint-summary">
                                <div class="pa-bp-row">
                                    <span class="pa-bp-label">Loaded:</span>
                                    <span class="pa-bp-val"><?php echo esc_html( $blueprint['session_name'] ?? '(unnamed)' ); ?></span>
                                </div>
                                <div class="pa-bp-row">
                                    <span class="pa-bp-label">Plugin:</span>
                                    <span class="pa-bp-val"><?php echo esc_html( $blueprint['plugin_name'] ?? '—' ); ?></span>
                                </div>
                                <div class="pa-bp-row">
                                    <span class="pa-bp-label">Tasks:</span>
                                    <span class="pa-bp-val"><?php echo intval( count( $blueprint['tasks'] ?? array() ) ); ?></span>
                                </div>
                                <?php if ( ! empty( $blueprint['estimated_duration_minutes'] ) ) : ?>
                                <div class="pa-bp-row">
                                    <span class="pa-bp-label">Est. duration:</span>
                                    <span class="pa-bp-val"><?php echo intval( $blueprint['estimated_duration_minutes'] ); ?> min</span>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="pa-card">
                        <div class="pa-card-title">2. Instructions</div>
                        <ol class="pa-instructions">
                            <li>Upload the test JSON blueprint above.</li>
                            <li>Read the task list once — the floating card in the bottom-right will guide you through each task.</li>
                            <li>Click <strong>Start test</strong> on the floating card (or here) to begin. A session will start recording.</li>
                            <li>Work through the tasks naturally. Use the Pain / Confused / Success markers in the original overlay whenever something feels off or right.</li>
                            <li>When finished, click <strong>End test</strong>. The session will close and you can view the report.</li>
                        </ol>

                        <div class="pa-controls">
                            <button id="pa-start-btn" class="pa-btn-primary-lg" <?php disabled( ! $blueprint || ($state['status'] ?? '') === 'running' ); ?>>
                                Start test
                            </button>
                            <button id="pa-end-btn" class="pa-btn-secondary-lg" <?php disabled( ($state['status'] ?? '') !== 'running' ); ?>>
                                End test
                            </button>
                        </div>
                        <div id="pa-state-badge" class="pa-state-badge pa-state-<?php echo esc_attr( $state['status'] ?? 'idle' ); ?>">
                            Status: <?php echo esc_html( $state['status'] ?? 'idle' ); ?>
                        </div>
                    </div>
                </div>

                <!-- Tasks column -->
                <div class="pa-test-col">
                    <div class="pa-card">
                        <div class="pa-card-title">Task list</div>
                        <?php if ( ! $blueprint || empty( $blueprint['tasks'] ) ) : ?>
                            <p class="pa-card-desc">No blueprint loaded yet. Upload one to see the task list.</p>
                        <?php else : ?>
                            <ol class="pa-task-list">
                                <?php foreach ( $blueprint['tasks'] as $i => $task ) : ?>
                                    <li class="pa-task-item">
                                        <div class="pa-task-title"><?php echo esc_html( $task['title'] ?? 'Untitled task' ); ?></div>
                                        <?php if ( ! empty( $task['description'] ) ) : ?>
                                            <div class="pa-task-desc"><?php echo esc_html( $task['description'] ); ?></div>
                                        <?php endif; ?>
                                        <div class="pa-task-meta">
                                            <?php if ( ! empty( $task['category'] ) ) : ?>
                                                <span class="pa-task-tag"><?php echo esc_html( $task['category'] ); ?></span>
                                            <?php endif; ?>
                                            <?php if ( ! empty( $task['estimated_duration_minutes'] ) ) : ?>
                                                <span class="pa-task-tag-light">~<?php echo intval( $task['estimated_duration_minutes'] ); ?> min</span>
                                            <?php endif; ?>
                                            <?php if ( ! empty( $task['starting_url'] ) ) : ?>
                                                <span class="pa-task-tag-light">start: <?php echo esc_html( $task['starting_url'] ); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </li>
                                <?php endforeach; ?>
                            </ol>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
        <?php
    }

    // ── State helpers ─────────────────────────────────────────────────────

    public static function get_blueprint() {
        $raw = get_option( self::OPT_BLUEPRINT, '' );
        if ( ! $raw ) {
            return null;
        }
        $bp = json_decode( $raw, true );
        return is_array( $bp ) ? $bp : null;
    }

    public static function get_state() {
        $raw = get_option( self::OPT_STATE, '' );
        if ( ! $raw ) {
            return array( 'status' => 'idle', 'current_task' => 0 );
        }
        $s = json_decode( $raw, true );
        return is_array( $s ) ? $s : array( 'status' => 'idle', 'current_task' => 0 );
    }

    public static function save_state( array $state ) {
        update_option( self::OPT_STATE, wp_json_encode( $state ) );
    }

    // ── AJAX: upload blueprint ────────────────────────────────────────────

    public static function ajax_upload_blueprint() {
        check_ajax_referer( 'pa_test_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $raw = wp_unslash( $_POST['blueprint'] ?? '' );
        if ( ! $raw ) {
            wp_send_json_error( 'No blueprint provided' );
        }

        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) {
            wp_send_json_error( 'Invalid JSON' );
        }

        // Light validation — the blueprint must have a tasks array.
        if ( empty( $decoded['tasks'] ) || ! is_array( $decoded['tasks'] ) ) {
            wp_send_json_error( 'Blueprint is missing a "tasks" array' );
        }

        // Store the canonical JSON form.
        update_option( self::OPT_BLUEPRINT, wp_json_encode( $decoded ) );

        // Reset the run state since we just loaded a new test.
        self::save_state( array(
            'status'       => 'idle',
            'current_task' => 0,
            'started_at'   => null,
            'ended_at'     => null,
            'session_id'   => null,
        ) );

        wp_send_json_success( array(
            'session_name' => $decoded['session_name'] ?? '(unnamed)',
            'plugin_name'  => $decoded['plugin_name']  ?? '',
            'task_count'   => count( $decoded['tasks'] ),
            'tasks'        => self::compact_task_list( $decoded['tasks'] ),
        ) );
    }

    private static function compact_task_list( array $tasks ) {
        $out = array();
        foreach ( $tasks as $t ) {
            $out[] = array(
                'id'           => $t['id']           ?? '',
                'title'        => $t['title']        ?? '',
                'description'  => $t['description']  ?? '',
                'starting_url' => $t['starting_url'] ?? '',
                'category'     => $t['category']     ?? '',
            );
        }
        return $out;
    }

    // ── AJAX: start test ──────────────────────────────────────────────────

    public static function ajax_start_test() {
        check_ajax_referer( 'pa_test_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $blueprint = self::get_blueprint();
        if ( ! $blueprint ) {
            wp_send_json_error( 'No blueprint loaded' );
        }

        // Guard: if there's already an active session, don't create another.
        // This makes the Start button safely idempotent — double-clicks, retries,
        // a stale tab calling start again, etc. all reuse the one session.
        $session_id = PA_Session::get_id();
        if ( ! $session_id ) {
            $session_id = PA_Session::start_new();
        }

        self::save_state( array(
            'status'       => 'running',
            'current_task' => 0,
            'started_at'   => time(),
            'ended_at'     => null,
            'session_id'   => $session_id,
        ) );

        wp_send_json_success( self::get_state() );
    }

    // ── AJAX: end test ────────────────────────────────────────────────────

    public static function ajax_end_test() {
        check_ajax_referer( 'pa_test_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $state = self::get_state();

        // Close the underlying PA session if there is one.
        if ( ! empty( $state['session_id'] ) ) {
            PA_DB::end_session( $state['session_id'] );
        }
        // Clear the active pointer so no further events are captured against
        // this session and no new session is implicitly created elsewhere.
        PA_Session::clear_active();

        $state['status']   = 'ended';
        $state['ended_at'] = time();
        self::save_state( $state );

        wp_send_json_success( $state );
    }

    // ── AJAX: get current state (polled by the floating card) ────────────

    public static function ajax_get_test_state() {
        check_ajax_referer( 'pa_test_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $bp    = self::get_blueprint();
        $state = self::get_state();

        $current_task = null;
        if ( $bp && isset( $bp['tasks'][ intval( $state['current_task'] ?? 0 ) ] ) ) {
            $current_task = $bp['tasks'][ intval( $state['current_task'] ?? 0 ) ];
        }

        wp_send_json_success( array(
            'state'        => $state,
            'has_blueprint'=> (bool) $bp,
            'session_name' => $bp['session_name'] ?? '',
            'task_count'   => $bp ? count( $bp['tasks'] ?? array() ) : 0,
            'current_task' => $current_task ? array(
                'id'           => $current_task['id']           ?? '',
                'title'        => $current_task['title']        ?? '',
                'description'  => $current_task['description']  ?? '',
                'starting_url' => $current_task['starting_url'] ?? '',
                'index'        => intval( $state['current_task'] ?? 0 ),
            ) : null,
        ) );
    }

    // ── AJAX: advance to next task ────────────────────────────────────────

    public static function ajax_advance_task() {
        check_ajax_referer( 'pa_test_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $bp    = self::get_blueprint();
        $state = self::get_state();

        if ( ! $bp ) {
            wp_send_json_error( 'No blueprint' );
        }

        $next = intval( $state['current_task'] ?? 0 ) + 1;
        $max  = count( $bp['tasks'] ?? array() );

        if ( $next >= $max ) {
            // Auto-end if past the last task.
            if ( ! empty( $state['session_id'] ) ) {
                PA_DB::end_session( $state['session_id'] );
            }
            PA_Session::clear_active();
            $state['status']       = 'ended';
            $state['ended_at']     = time();
            $state['current_task'] = $max - 1;
        } else {
            $state['current_task'] = $next;
        }

        self::save_state( $state );
        wp_send_json_success( $state );
    }

    // ── Floating card render ──────────────────────────────────────────────

    public static function render_floating_card() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        // The card itself is rendered + driven by test-card.js. We only need
        // an anchor div so the script has something to mount into, and we
        // make sure the CSS/JS are loaded in this footer context too —
        // admin_enqueue_scripts and wp_enqueue_scripts already handled that,
        // but on some screens (e.g. login) those don't fire, so we bail out
        // gracefully if PA_TEST isn't defined client-side.
        echo '<div id="pa-test-card-root"></div>';
    }
}
