<?php
defined( 'ABSPATH' ) || exit;

class PA_Screenshots {

    public static function init() {
        add_action( 'wp_ajax_pa_store_screenshot', array( __CLASS__, 'ajax_store_screenshot' ) );
    }

    public static function ajax_store_screenshot() {
        check_ajax_referer( 'pa_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $session_id = sanitize_text_field( wp_unslash( $_POST['session_id'] ?? '' ) );
        $marker_id  = intval( $_POST['marker_id'] ?? 0 );
        $image_data = wp_unslash( $_POST['image_data'] ?? '' );

        if ( ! $session_id || ! $image_data ) {
            wp_send_json_error( 'Missing data' );
        }

        // Validate base64 PNG/JPEG
        if ( ! preg_match( '/^data:image\/(png|jpeg|webp);base64,/', $image_data ) ) {
            wp_send_json_error( 'Invalid image format' );
        }

        $base64 = preg_replace( '/^data:image\/\w+;base64,/', '', $image_data );
        $binary = base64_decode( $base64, true );
        if ( $binary === false || strlen( $binary ) < 100 ) {
            wp_send_json_error( 'Decode failed' );
        }

        // Cap at ~1MB after decoding
        if ( strlen( $binary ) > 1048576 ) {
            wp_send_json_error( 'Image too large' );
        }

        $upload_dir = wp_upload_dir();
        $pa_dir     = $upload_dir['basedir'] . '/pressactivate/screenshots';
        wp_mkdir_p( $pa_dir );

        // Protect the directory
        if ( ! file_exists( $pa_dir . '/.htaccess' ) ) {
            file_put_contents( $pa_dir . '/.htaccess', "Options -Indexes\ndeny from all\n" );
        }
        if ( ! file_exists( $pa_dir . '/index.php' ) ) {
            file_put_contents( $pa_dir . '/index.php', "<?php // silence\n" );
        }

        $ext      = 'jpg';
        $filename = sanitize_file_name( $session_id . '_' . $marker_id . '_' . time() . '.' . $ext );
        $filepath = $pa_dir . '/' . $filename;

        // Re-encode as JPEG to normalise format and reduce size
        $img = @imagecreatefromstring( $binary );
        if ( $img ) {
            imagejpeg( $img, $filepath, 72 );
            imagedestroy( $img );
        } else {
            file_put_contents( $filepath, $binary );
        }

        $size = file_exists( $filepath ) ? filesize( $filepath ) : 0;

        $screenshot_id = PA_DB::insert_screenshot( array(
            'session_id'  => $session_id,
            'marker_id'   => $marker_id ?: null,
            'file_path'   => 'pressactivate/screenshots/' . $filename,
            'file_size'   => $size,
            'captured_at' => time() * 1000,
        ) );

        // Link back to marker
        if ( $marker_id ) {
            global $wpdb;
            $wpdb->update(
                $wpdb->prefix . 'pa_markers',
                array( 'screenshot_id' => $screenshot_id ),
                array( 'id' => $marker_id )
            );
        }

        wp_send_json_success( array( 'screenshot_id' => $screenshot_id ) );
    }

    public static function get_screenshot_url( $relative_path ) {
        $upload_dir = wp_upload_dir();
        return $upload_dir['baseurl'] . '/' . $relative_path;
    }
}
