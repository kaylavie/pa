=== PressActivate ===
Contributors: pressactivate
Tags: onboarding, ux, user testing, usability
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.3.1
Requires PHP: 7.4
License: GPLv2 or later

User-testing tooling for WordPress. Upload a JSON test blueprint, run guided sessions, and capture behavioral evidence with a persistent floating control card.

== Description ==

PressActivate runs structured user tests inside WordPress. Upload a JSON blueprint describing the tasks and questions, then drive the session from a persistent floating card that follows the user on every admin and frontend page.

It tracks:
* Clicks, navigation, searches, plugin installs/activations
* Form submissions and AJAX errors
* Scroll depth and viewport context
* User-triggered markers: Pain, Confused, Success, Finish
* Screenshots at marker events

A single session is created the moment you click Start and closed when you click End — one click, one session.

== Installation ==

1. Upload the `pressactivate` folder to `/wp-content/plugins/`
2. Activate the plugin — you'll be redirected to the User Test page
3. Upload a JSON blueprint and click Start to begin recording

== Changelog ==

= 1.3.1 =
* Fixed: web report upload now strips screenshots before POST. Free-tier payloads with 10+ base64 JPEGs were exceeding Playground's fetch body limit, producing a 400 from the Worker.
* Improved error reporting: API error messages now surface to the user instead of a generic "HTTP NNN".

= 1.3.0 =
* Added: "Generate web report" now works. Uploads the session payload to the pressactivate.com reports API and redirects to the shareable URL.
* Anonymous uploads are rate-limited to 3 per day per IP by the API.
* Upload errors (rate limit, validation, network) surface inline on the session report page.

= 1.2.0 =
* Fixed: only one session is created per Start click. Previously, every admin page load could spawn an extra session.
* Sessions are now bookended explicitly by the Start and End buttons; no implicit auto-creation.
* Removed: AI classification feature, Settings page, and the Anthropic API key field.

= 1.1.0 =
* Added User Test workflow: activation redirects to a new "User Test" admin page.
* Operators can upload a JSON blueprint describing test tasks and questions.
* New persistent floating card in the bottom-right of every page (admin and frontend) shows current task and Start / End controls.
* Card position is draggable and remembered per browser.

= 1.0.0 =
* Initial release
