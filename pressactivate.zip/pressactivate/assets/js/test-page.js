/**
 * PressActivate — User Test admin page.
 *
 * Wires up the file dropzone for blueprint upload and keeps the page's
 * Start / End buttons in sync with the floating card.
 */
(function () {
  'use strict';

  if (typeof PA_TEST === 'undefined') return;

  // ── DOM refs ───────────────────────────────────────────────────────────
  const dropzone   = document.getElementById('pa-dropzone');
  const fileInput  = document.getElementById('pa-bp-file');
  const feedback   = document.getElementById('pa-upload-feedback');
  const startBtn   = document.getElementById('pa-start-btn');
  const endBtn     = document.getElementById('pa-end-btn');
  const stateBadge = document.getElementById('pa-state-badge');

  if (!dropzone || !fileInput) return;

  // ── AJAX helper ────────────────────────────────────────────────────────
  function postAjax(action, extra) {
    const body = new URLSearchParams(Object.assign({
      action: action,
      nonce:  PA_TEST.nonce,
    }, extra || {}));
    return fetch(PA_TEST.ajaxurl, { method: 'POST', credentials: 'same-origin', body: body })
      .then(function (r) { return r.json(); });
  }

  function setFeedback(kind, msg) {
    feedback.hidden = false;
    feedback.className = 'pa-upload-feedback pa-fb-' + kind;
    feedback.textContent = msg;
  }

  // ── Dropzone behavior ──────────────────────────────────────────────────
  dropzone.addEventListener('click', function () { fileInput.click(); });
  dropzone.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') { fileInput.click(); e.preventDefault(); }
  });
  dropzone.setAttribute('tabindex', '0');

  ['dragenter', 'dragover'].forEach(function (ev) {
    dropzone.addEventListener(ev, function (e) {
      e.preventDefault();
      dropzone.classList.add('pa-dz-active');
    });
  });
  ['dragleave', 'drop'].forEach(function (ev) {
    dropzone.addEventListener(ev, function (e) {
      e.preventDefault();
      dropzone.classList.remove('pa-dz-active');
    });
  });

  dropzone.addEventListener('drop', function (e) {
    const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (file) handleFile(file);
  });
  fileInput.addEventListener('change', function () {
    const file = fileInput.files && fileInput.files[0];
    if (file) handleFile(file);
  });

  function handleFile(file) {
    if (!/\.json$/i.test(file.name) && file.type !== 'application/json') {
      setFeedback('error', 'Please upload a .json file.');
      return;
    }
    // Cap at 1MB — the blueprints described are tiny.
    if (file.size > 1024 * 1024) {
      setFeedback('error', 'File is too large (max 1MB).');
      return;
    }
    setFeedback('info', 'Reading ' + file.name + '…');

    const reader = new FileReader();
    reader.onload = function () {
      const text = reader.result;
      // Validate JSON client-side before sending.
      try {
        JSON.parse(text);
      } catch (err) {
        setFeedback('error', 'Invalid JSON: ' + err.message);
        return;
      }
      uploadBlueprint(text);
    };
    reader.onerror = function () {
      setFeedback('error', 'Could not read the file.');
    };
    reader.readAsText(file);
  }

  function uploadBlueprint(jsonText) {
    setFeedback('info', 'Uploading…');
    postAjax('pa_upload_blueprint', { blueprint: jsonText }).then(function (r) {
      if (!r || !r.success) {
        setFeedback('error', (r && r.data) ? r.data : 'Upload failed.');
        return;
      }
      const d = r.data;
      setFeedback(
        'success',
        'Loaded "' + (d.session_name || 'test') + '" — ' + d.task_count + ' task' + (d.task_count === 1 ? '' : 's') + '.'
      );
      // Tell the floating card to refresh, then reload the page so the
      // task list and disabled state of the buttons update from PHP.
      if (window.PA_TestCard && window.PA_TestCard.refresh) {
        window.PA_TestCard.refresh();
      }
      // Soft reload after a beat so the user sees the success message.
      setTimeout(function () { window.location.reload(); }, 800);
    }).catch(function () {
      setFeedback('error', 'Upload failed (network).');
    });
  }

  // ── Page buttons mirror the floating card ─────────────────────────────
  if (startBtn) {
    startBtn.addEventListener('click', function () {
      startBtn.disabled = true;
      postAjax('pa_start_test').then(function (r) {
        if (!r || !r.success) {
          alert((r && r.data) || 'Could not start test');
          startBtn.disabled = false;
          return;
        }
        if (window.PA_TestCard && window.PA_TestCard.refresh) {
          window.PA_TestCard.refresh();
        }
        applyState(r.data);
      });
    });
  }

  if (endBtn) {
    endBtn.addEventListener('click', function () {
      if (!confirm('End the test now? The session will close.')) return;
      endBtn.disabled = true;
      postAjax('pa_end_test').then(function (r) {
        endBtn.disabled = false;
        if (window.PA_TestCard && window.PA_TestCard.refresh) {
          window.PA_TestCard.refresh();
        }
        if (r && r.success) applyState(r.data);
      });
    });
  }

  function applyState(state) {
    if (!state) return;
    const status = state.status || 'idle';
    if (startBtn) startBtn.disabled = (status === 'running');
    if (endBtn)   endBtn.disabled   = (status !== 'running');
    if (stateBadge) {
      stateBadge.className = 'pa-state-badge pa-state-' + status;
      stateBadge.textContent = 'Status: ' + status;
    }
  }

  // Also listen to broadcasts from the floating card.
  window.addEventListener('pa-test-state', function (e) {
    if (e.detail && e.detail.state) applyState(e.detail.state);
  });

})();
