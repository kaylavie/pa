/**
 * PressActivate — admin report upload.
 *
 * Replaces the original server-side wp_remote_post upload with a two-step
 * client flow:
 *
 *   1. AJAX to admin-ajax.php?action=pa_get_report_payload to fetch the
 *      built report.v1 JSON. PHP does the heavy lifting (DB queries, schema
 *      shaping); we just receive the result.
 *
 *   2. POST that JSON straight to the Worker. The Worker has permissive
 *      CORS (Access-Control-Allow-Origin: *) so this works from anywhere
 *      including WordPress Playground, where outbound PHP fetches are
 *      proxied/restricted and were producing opaque 400 errors.
 *
 *   3. On 201 Created, navigate to the report URL the Worker returned.
 *
 * No build step; vanilla JS. Localized config arrives via window.PA_UPLOAD
 * (see PA_Admin::enqueue_report_assets).
 */

( function() {
	'use strict';

	const cfg = window.PA_UPLOAD;
	if ( ! cfg ) return;

	const button = document.getElementById( 'pa-generate-web-report' );
	const status = document.getElementById( 'pa-upload-status' );
	if ( ! button || ! status ) return;

	button.addEventListener( 'click', async function( e ) {
		e.preventDefault();
		if ( button.disabled ) return;

		setStatus( 'loading', 'Building report…' );
		button.disabled = true;

		try {
			const payload = await fetchPayload();
			setStatus( 'loading', 'Uploading to pressactivate.com…' );

			const result = await uploadToWorker( payload );

			setStatus( 'success', 'Done. Redirecting…' );
			window.location.href = result.report_url;
		} catch ( err ) {
			console.error( 'PressActivate upload failed:', err );
			setStatus( 'error', err.message || 'Upload failed.' );
			button.disabled = false;
		}
	} );

	/**
	 * Step 1: ask PHP for the report payload.
	 */
	async function fetchPayload() {
		const form = new FormData();
		form.append( 'action',     'pa_get_report_payload' );
		form.append( 'session_id', cfg.session_id );
		form.append( '_ajax_nonce', cfg.nonce );

		const res = await fetch( cfg.ajax_url, {
			method:      'POST',
			credentials: 'same-origin',
			body:        form,
		} );

		const json = await res.json().catch( () => null );
		if ( ! res.ok || ! json || ! json.success ) {
			const msg = json && json.data && json.data.message
				? json.data.message
				: 'Could not build the report payload.';
			throw new Error( msg );
		}
		return json.data;
	}

	/**
	 * Step 2: POST payload directly to the Worker.
	 *
	 * The Worker returns:
	 *   201 { report_url, slug, report_id, ... }   on first upload
	 *   200 { report_url, idempotent: true, ... }  on resubmission
	 *   422 { error: 'validation_failed', errors: [...] }
	 *   429 { error: 'rate_limited',     message, retry_after_seconds }
	 *   400 { error: 'invalid_json',     message }
	 */
	async function uploadToWorker( payload ) {
		const endpoint = cfg.api_base.replace( /\/+$/, '' ) + '/v1/reports';

		const res = await fetch( endpoint, {
			method:  'POST',
			headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
			body:    JSON.stringify( payload ),
		} );

		const data = await res.json().catch( () => null );

		if ( res.ok && data && data.report_url ) {
			return data;
		}

		// Build a useful error from whatever the Worker returned.
		if ( res.status === 422 && data && Array.isArray( data.errors ) && data.errors.length ) {
			const first = data.errors[ 0 ];
			throw new Error( 'Validation failed at ' + ( first.path || '?' ) + ': ' + ( first.message || 'invalid' ) );
		}
		if ( data && data.message ) {
			throw new Error( data.message );
		}
		throw new Error( 'Reports API returned HTTP ' + res.status + '.' );
	}

	function setStatus( kind, text ) {
		status.className = 'pa-upload-status pa-upload-status-' + kind;
		status.textContent = text;
	}

} )();
