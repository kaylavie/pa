/**
 * PressActivate — admin capture layer
 * Tracks high-value events, renders overlay, handles markers and screenshots.
 */
(function () {
  'use strict';

  if (typeof PA === 'undefined') return;

  // ── State ──────────────────────────────────────────────────────────────
  const state = {
    buffer:      [],
    flushing:    false,
    overlayOpen: false,
    pendingMarker: null,
  };

  // ── Helpers ────────────────────────────────────────────────────────────

  function ts() { return Date.now(); }

  function getScreenContext() {
    return {
      screen:  PA.screen.id   || '',
      base:    PA.screen.base || '',
      url:     window.location.href,
      title:   document.title,
    };
  }

  function semanticInfo(el) {
    if (!el) return {};
    // Walk up to find meaningful text
    let text = (el.innerText || el.textContent || '').trim().slice(0, 120);
    if (!text && el.value) text = el.value.slice(0, 120);

    const aria  = el.getAttribute('aria-label') || el.getAttribute('title') || '';
    const tag   = el.tagName ? el.tagName.toLowerCase() : '';
    const id    = el.id || '';
    let cls     = (el.className && typeof el.className === 'string') ? el.className.replace(/\s+/g, ' ').trim().slice(0, 100) : '';

    // Try to get nearest label
    let label = '';
    const labelEl = el.closest('label') || (el.id && document.querySelector('label[for="' + el.id + '"]'));
    if (labelEl) label = (labelEl.innerText || '').trim().slice(0, 80);

    // WP screen context from body class
    const bodyClasses = document.body.className;
    const screenMatch = bodyClasses.match(/(?:^|\s)(wp-admin)(?:\s|$)/);

    return { text, aria_label: aria, element_tag: tag, element_id: id, selector: cls, label };
  }

  function push(type, extra) {
    const ctx  = getScreenContext();
    const info = extra.element ? semanticInfo(extra.element) : {};
    delete extra.element;

    const evt = Object.assign({
      event_type:   type,
      screen:       ctx.screen,
      viewport_w:   window.innerWidth,
      viewport_h:   window.innerHeight,
      timestamp:    ts(),
    }, info, extra);

    state.buffer.push(evt);

    if (state.buffer.length >= PA.buffer_limit) {
      flushBuffer();
    }
  }

  // ── Flush ──────────────────────────────────────────────────────────────

  function flushBuffer() {
    if (state.flushing || state.buffer.length === 0) return;
    state.flushing = true;

    const batch = state.buffer.splice(0, state.buffer.length);
    const body  = new URLSearchParams({
      action:     'pa_store_events',
      nonce:      PA.nonce,
      session_id: PA.session_id,
      events:     JSON.stringify(batch),
    });

    fetch(PA.ajaxurl, { method: 'POST', body })
      .catch(() => {})
      .finally(() => { state.flushing = false; });
  }

  setInterval(flushBuffer, PA.flush_interval);
  window.addEventListener('beforeunload', flushBuffer);

  // ── Event listeners ────────────────────────────────────────────────────

  // Clicks
  document.addEventListener('click', function (e) {
    const target = e.target.closest('a, button, input[type="submit"], input[type="button"], .wp-menu-name') || e.target;
    push('click', { element: target });
  }, true);

  // Page load
  push('page_load', { meta: { referrer: document.referrer } });

  // WP search boxes
  document.addEventListener('input', function (e) {
    const el = e.target;
    if (el.matches('#plugin-search-input, #search-input, .search-box input')) {
      push('search', { element: el, meta: { query: el.value.slice(0, 80) } });
    }
  }, true);

  // Menu navigation
  document.querySelectorAll('#adminmenu a').forEach(function (link) {
    link.addEventListener('click', function () {
      push('menu_open', {
        element: link,
        meta: { href: link.getAttribute('href') },
      });
    });
  });

  // Form submits
  document.addEventListener('submit', function (e) {
    const form = e.target;
    push('form_submit', {
      element: form,
      meta: { action: form.getAttribute('action') || '' },
    });
  }, true);

  // AJAX errors (WP uses jQuery internally)
  if (typeof jQuery !== 'undefined') {
    jQuery(document).ajaxError(function (event, xhr, settings) {
      push('ajax_error', {
        meta: {
          url:    settings.url,
          status: xhr.status,
          text:   xhr.statusText,
        },
      });
    });
  }

  // Plugin install / activate actions — intercept WP install buttons
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('.install-now, .activate-now, [data-slug]');
    if (!btn) return;
    const slug   = btn.dataset.slug || '';
    const action = btn.classList.contains('activate-now') ? 'plugin_activate' : 'plugin_install';
    push(action, { element: btn, meta: { plugin_slug: slug } });
  }, true);

  // Scroll depth (debounced, records max reached)
  let maxScroll = 0;
  let scrollTimer;
  window.addEventListener('scroll', function () {
    clearTimeout(scrollTimer);
    scrollTimer = setTimeout(function () {
      const depth = Math.round(
        ((window.scrollY + window.innerHeight) / Math.max(document.body.scrollHeight, 1)) * 100
      );
      if (depth > maxScroll + 10) {
        maxScroll = depth;
        push('scroll', { scroll_depth: depth });
      }
    }, 500);
  });

  // ── Overlay ────────────────────────────────────────────────────────────

  const MARKERS = [
    { type: 'pain',     label: 'Pain',      icon: '✕', title: 'Something felt wrong or frustrating' },
    { type: 'confused', label: 'Confused',  icon: '?', title: 'Something was unclear or confusing' },
    { type: 'success',  label: 'Success',   icon: '✓', title: 'Something worked well' },
    { type: 'finish',   label: 'Finish',    icon: '⏹', title: 'End this session' },
  ];

  const overlay = document.createElement('div');
  overlay.id = 'pa-overlay';
  overlay.innerHTML = `
    <button id="pa-toggle" title="PressActivate session tracker" aria-label="PressActivate session tracker">
      <span class="pa-icon-ring"></span>
    </button>
    <div id="pa-panel" role="dialog" aria-label="PressActivate markers">
      <div class="pa-panel-header">
        <span class="pa-panel-title">PressActivate</span>
        <button id="pa-close" aria-label="Close panel">✕</button>
      </div>
      <div class="pa-panel-body">
        ${MARKERS.map(m => `
          <button class="pa-marker-btn" data-type="${m.type}" title="${m.title}">
            <span class="pa-marker-icon">${m.icon}</span>
            <span>${m.label}</span>
          </button>
        `).join('')}
      </div>
    </div>
    <div id="pa-annotation-modal" hidden>
      <div class="pa-modal-inner">
        <div class="pa-modal-header">
          <span id="pa-modal-title">What happened?</span>
          <button id="pa-modal-cancel" aria-label="Cancel">✕</button>
        </div>
        <textarea id="pa-annotation" placeholder="Optional: describe what confused or blocked you…" rows="3"></textarea>
        <div class="pa-modal-footer">
          <button id="pa-modal-skip" class="pa-btn-text">Skip</button>
          <button id="pa-modal-submit" class="pa-btn-primary">Submit</button>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  const toggleBtn   = document.getElementById('pa-toggle');
  const panel       = document.getElementById('pa-panel');
  const closeBtn    = document.getElementById('pa-close');
  const modal       = document.getElementById('pa-annotation-modal');
  const annotText   = document.getElementById('pa-annotation');
  const modalCancel = document.getElementById('pa-modal-cancel');
  const modalSkip   = document.getElementById('pa-modal-skip');
  const modalSubmit = document.getElementById('pa-modal-submit');
  const modalTitle  = document.getElementById('pa-modal-title');

  toggleBtn.addEventListener('click', function () {
    state.overlayOpen = !state.overlayOpen;
    panel.classList.toggle('pa-panel-open', state.overlayOpen);
    panel.hidden = !state.overlayOpen;
  });
  closeBtn.addEventListener('click', function () {
    state.overlayOpen = false;
    panel.hidden = true;
    panel.classList.remove('pa-panel-open');
  });
  panel.hidden = true;

  // Marker buttons
  panel.querySelectorAll('.pa-marker-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const type = btn.dataset.type;
      // Close panel
      state.overlayOpen = false;
      panel.hidden = true;

      // For pain/confused — show annotation modal
      if (type === 'pain' || type === 'confused') {
        state.pendingMarker = type;
        modalTitle.textContent = type === 'pain' ? 'What felt wrong?' : 'What was confusing?';
        annotText.value = '';
        modal.hidden = false;
      } else {
        // success / finish — submit directly, take screenshot
        fireMarker(type, '');
      }
    });
  });

  modalCancel.addEventListener('click', function () {
    modal.hidden = true;
    state.pendingMarker = null;
  });
  modalSkip.addEventListener('click', function () {
    modal.hidden = true;
    fireMarker(state.pendingMarker, '');
    state.pendingMarker = null;
  });
  modalSubmit.addEventListener('click', function () {
    modal.hidden = true;
    fireMarker(state.pendingMarker, annotText.value.trim());
    state.pendingMarker = null;
  });

  // ── Marker + Screenshot ────────────────────────────────────────────────

  function fireMarker(type, annotation) {
    if (!type) return;

    const ctx         = getScreenContext();
    const eventBuffer = JSON.stringify(state.buffer.slice(-50));

    // 1. Store the marker first
    const body = new URLSearchParams({
      action:       'pa_store_marker',
      nonce:        PA.nonce,
      session_id:   PA.session_id,
      marker_type:  type,
      annotation:   annotation,
      screen:       ctx.screen,
      event_buffer: eventBuffer,
    });

    fetch(PA.ajaxurl, { method: 'POST', body })
      .then(r => r.json())
      .then(function (d) {
        if (!d.success) return;
        const markerId = d.data.marker_id;

        // 2. Capture screenshot
        if (typeof html2canvas !== 'undefined') {
          html2canvas(document.body, {
            scale:           0.6,
            useCORS:         true,
            logging:         false,
            allowTaint:      true,
            ignoreElements:  function (el) { return el.id === 'pa-overlay'; },
          }).then(function (canvas) {
            const imageData = canvas.toDataURL('image/jpeg', 0.65);
            const ssBody    = new URLSearchParams({
              action:      'pa_store_screenshot',
              nonce:       PA.nonce,
              session_id:  PA.session_id,
              marker_id:   markerId,
              image_data:  imageData,
            });
            fetch(PA.ajaxurl, { method: 'POST', body: ssBody }).catch(() => {});
          }).catch(() => {});
        }

        // 3. If finish — end session and redirect to report
        if (type === 'finish') {
          flushBuffer();
          const endBody = new URLSearchParams({
            action:     'pa_end_session',
            nonce:      PA.nonce,
            session_id: PA.session_id,
          });
          fetch(PA.ajaxurl, { method: 'POST', body: endBody })
            .finally(function () {
              window.location.href = PA.ajaxurl.replace('admin-ajax.php', '')
                + 'admin.php?page=pressactivate-report&session_id=' + encodeURIComponent(PA.session_id);
            });
        }
      })
      .catch(() => {});
  }

})();
