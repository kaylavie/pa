/**
 * PressActivate — floating test card.
 *
 * Mounts a small, draggable card in the bottom-right of every page (admin and
 * frontend) that follows the user around. It shows the current test status
 * and current task, and exposes Start / End / Next-task controls.
 *
 * State lives server-side as a WP option, so the card stays in sync as the
 * user navigates from page to page. We poll lightly to pick up changes made
 * elsewhere (e.g. uploading a new blueprint in another tab).
 */
(function () {
  'use strict';

  if (typeof PA_TEST === 'undefined') return;

  // ── Mount target ───────────────────────────────────────────────────────
  let root = document.getElementById('pa-test-card-root');
  if (!root) {
    root = document.createElement('div');
    root.id = 'pa-test-card-root';
    document.body.appendChild(root);
  }

  // ── Card scaffolding ───────────────────────────────────────────────────
  const card = document.createElement('div');
  card.id = 'pa-test-card';
  // Start hidden — we reveal only after the first state fetch returns, so
  // the user never sees the placeholder "idle/empty" state flash before
  // the real state lands. Without this, the card jumps from disabled-Start
  // to running-with-current-task on every page load.
  card.style.visibility = 'hidden';
  card.setAttribute('role', 'region');
  card.setAttribute('aria-label', 'PressActivate user test');
  card.innerHTML = `
    <div class="pa-tc-header">
      <span class="pa-tc-dot" data-status="idle"></span>
      <span class="pa-tc-title">User Test</span>
      <button class="pa-tc-collapse" aria-label="Collapse">–</button>
    </div>
    <div class="pa-tc-body">
      <div class="pa-tc-empty" hidden>
        No blueprint loaded.
        <a class="pa-tc-link" href="">Upload one →</a>
      </div>
      <div class="pa-tc-idle" hidden>
        <div class="pa-tc-session-name"></div>
        <div class="pa-tc-task-count"></div>
        <p class="pa-tc-hint">Click Start to begin recording.</p>
      </div>
      <div class="pa-tc-running" hidden>
        <div class="pa-tc-task-label">Current task</div>
        <div class="pa-tc-task-title"></div>
        <div class="pa-tc-task-desc"></div>
        <div class="pa-tc-task-pos"></div>
      </div>
      <div class="pa-tc-ended" hidden>
        <div class="pa-tc-ended-title">Test ended</div>
        <p class="pa-tc-hint">View results in PressActivate → Sessions.</p>
      </div>
      <div class="pa-tc-actions">
        <button class="pa-tc-btn pa-tc-start" disabled>Start test</button>
        <button class="pa-tc-btn pa-tc-next" hidden>Next task</button>
        <button class="pa-tc-btn pa-tc-end pa-tc-btn-danger" hidden>End test</button>
      </div>
    </div>
    <div class="pa-tc-collapsed" hidden>
      <span class="pa-tc-dot" data-status="idle"></span>
      <span class="pa-tc-collapsed-text">Test</span>
    </div>
  `;
  root.appendChild(card);

  // ── References ─────────────────────────────────────────────────────────
  const els = {
    dot:           card.querySelector('.pa-tc-header .pa-tc-dot'),
    collapsedDot:  card.querySelector('.pa-tc-collapsed .pa-tc-dot'),
    title:         card.querySelector('.pa-tc-title'),
    collapseBtn:   card.querySelector('.pa-tc-collapse'),
    body:          card.querySelector('.pa-tc-body'),
    collapsed:     card.querySelector('.pa-tc-collapsed'),

    empty:         card.querySelector('.pa-tc-empty'),
    emptyLink:     card.querySelector('.pa-tc-empty .pa-tc-link'),
    idle:          card.querySelector('.pa-tc-idle'),
    sessionName:   card.querySelector('.pa-tc-session-name'),
    taskCount:     card.querySelector('.pa-tc-task-count'),
    running:       card.querySelector('.pa-tc-running'),
    taskTitle:     card.querySelector('.pa-tc-task-title'),
    taskDesc:      card.querySelector('.pa-tc-task-desc'),
    taskPos:       card.querySelector('.pa-tc-task-pos'),
    ended:         card.querySelector('.pa-tc-ended'),

    startBtn:      card.querySelector('.pa-tc-start'),
    nextBtn:       card.querySelector('.pa-tc-next'),
    endBtn:        card.querySelector('.pa-tc-end'),
  };

  // The "Upload one" link points back to the User Test admin page — only
  // useful when we're in admin context. On the frontend we'll just send the
  // user to /wp-admin/.
  els.emptyLink.href = (PA_TEST.context === 'admin')
    ? 'admin.php?page=pa-user-test'
    : '/wp-admin/admin.php?page=pa-user-test';

  // ── Collapse / expand (state persists in localStorage) ────────────────
  const COLLAPSED_KEY = 'pa_tc_collapsed';
  function applyCollapsed(collapsed) {
    els.body.hidden      = collapsed;
    els.collapsed.hidden = !collapsed;
    els.collapseBtn.textContent = collapsed ? '+' : '–';
    card.classList.toggle('pa-tc-is-collapsed', collapsed);
  }
  applyCollapsed(localStorage.getItem(COLLAPSED_KEY) === '1');

  els.collapseBtn.addEventListener('click', function () {
    const next = !card.classList.contains('pa-tc-is-collapsed');
    localStorage.setItem(COLLAPSED_KEY, next ? '1' : '0');
    applyCollapsed(next);
  });
  els.collapsed.addEventListener('click', function () {
    localStorage.setItem(COLLAPSED_KEY, '0');
    applyCollapsed(false);
  });

  // ── AJAX helper ────────────────────────────────────────────────────────
  function postAjax(action, extra) {
    const body = new URLSearchParams(Object.assign({
      action: action,
      nonce:  PA_TEST.nonce,
    }, extra || {}));
    return fetch(PA_TEST.ajaxurl, { method: 'POST', credentials: 'same-origin', body: body })
      .then(function (r) { return r.json(); });
  }

  // ── Render based on server state ──────────────────────────────────────
  function render(payload) {
    if (!payload) return;
    const state         = payload.state || {};
    const hasBp         = !!payload.has_blueprint;
    const currentTask   = payload.current_task;
    const status        = state.status || 'idle';

    // Hide all view-states first.
    els.empty.hidden   = true;
    els.idle.hidden    = true;
    els.running.hidden = true;
    els.ended.hidden   = true;

    // Status dot.
    els.dot.setAttribute('data-status', status);
    els.collapsedDot.setAttribute('data-status', status);

    // Button defaults.
    els.startBtn.hidden = false;
    els.startBtn.disabled = false;
    els.nextBtn.hidden = true;
    els.endBtn.hidden  = true;

    if (!hasBp) {
      els.empty.hidden = false;
      els.startBtn.disabled = true;
      return;
    }

    if (status === 'running') {
      els.running.hidden = false;
      els.startBtn.hidden = true;
      els.nextBtn.hidden  = false;
      els.endBtn.hidden   = false;

      if (currentTask) {
        els.taskTitle.textContent = currentTask.title || '(untitled task)';
        els.taskDesc.textContent  = currentTask.description || '';
        const pos = currentTask.index + 1;
        const tot = payload.task_count || 1;
        els.taskPos.textContent = 'Task ' + pos + ' of ' + tot;
      }
    } else if (status === 'ended') {
      els.ended.hidden = false;
      els.startBtn.hidden = true;
    } else {
      // idle
      els.idle.hidden = false;
      els.sessionName.textContent = payload.session_name || 'Untitled test';
      els.taskCount.textContent   = (payload.task_count || 0) + ' task' + (payload.task_count === 1 ? '' : 's');
    }

    // Reveal the card on the first render — subsequent renders are no-ops here.
    // visibility is used instead of display so the layout/position is stable
    // (display:none would re-trigger layout when the card appears).
    if (card.style.visibility === 'hidden') {
      card.style.visibility = 'visible';
    }
  }

  // ── Server sync ────────────────────────────────────────────────────────
  function fetchState() {
    return postAjax('pa_get_test_state').then(function (r) {
      if (r && r.success) {
        render(r.data);
        // Broadcast so the User Test page can update its inline controls too.
        window.dispatchEvent(new CustomEvent('pa-test-state', { detail: r.data }));
        return r.data;
      }
      // Successful HTTP but unsuccessful AJAX — reveal anyway with empty state
      // so the card doesn't stay invisible forever.
      revealIfHidden();
    }).catch(function () {
      // Network error — same fallback.
      revealIfHidden();
    });
  }

  function revealIfHidden() {
    if (card.style.visibility === 'hidden') {
      card.style.visibility = 'visible';
    }
  }

  // Initial render + light polling. We poll instead of using server-sent
  // events because the WP context here is a regular page, not a long-lived
  // connection — and the test state changes maybe once a minute at most.
  fetchState();
  setInterval(fetchState, 5000);

  // ── Button handlers ────────────────────────────────────────────────────
  els.startBtn.addEventListener('click', function () {
    els.startBtn.disabled = true;
    postAjax('pa_start_test').then(function (r) {
      if (!r || !r.success) {
        alert(r && r.data ? r.data : 'Could not start test');
        els.startBtn.disabled = false;
        return;
      }
      fetchState();
    });
  });

  els.endBtn.addEventListener('click', function () {
    if (!confirm('End the test now? The session will close.')) return;
    els.endBtn.disabled = true;
    postAjax('pa_end_test').then(function () {
      els.endBtn.disabled = false;
      fetchState();
    });
  });

  els.nextBtn.addEventListener('click', function () {
    els.nextBtn.disabled = true;
    postAjax('pa_advance_task').then(function () {
      els.nextBtn.disabled = false;
      fetchState();
    });
  });

  // ── Drag to reposition (sticky per-browser) ────────────────────────────
  // We let the user drag the card by its header in case it overlaps with
  // something they need to click. Position survives in localStorage.
  const POS_KEY = 'pa_tc_pos';
  const savedPos = (function () {
    try { return JSON.parse(localStorage.getItem(POS_KEY) || 'null'); }
    catch (e) { return null; }
  })();
  if (savedPos && typeof savedPos.right === 'number' && typeof savedPos.bottom === 'number') {
    card.style.right  = savedPos.right  + 'px';
    card.style.bottom = savedPos.bottom + 'px';
  }

  const header = card.querySelector('.pa-tc-header');
  let dragging = false;
  let startX, startY, startRight, startBottom;

  header.addEventListener('mousedown', function (e) {
    // Don't start a drag if the click was on the collapse button.
    if (e.target.closest('.pa-tc-collapse')) return;
    dragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = card.getBoundingClientRect();
    startRight  = window.innerWidth  - rect.right;
    startBottom = window.innerHeight - rect.bottom;
    e.preventDefault();
  });
  document.addEventListener('mousemove', function (e) {
    if (!dragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    const newRight  = Math.max(8, startRight  - dx);
    const newBottom = Math.max(8, startBottom - dy);
    card.style.right  = newRight  + 'px';
    card.style.bottom = newBottom + 'px';
  });
  document.addEventListener('mouseup', function () {
    if (!dragging) return;
    dragging = false;
    const rect = card.getBoundingClientRect();
    localStorage.setItem(POS_KEY, JSON.stringify({
      right:  Math.round(window.innerWidth  - rect.right),
      bottom: Math.round(window.innerHeight - rect.bottom),
    }));
  });

  // Expose a minimal API for the User Test admin page to refresh after upload.
  window.PA_TestCard = { refresh: fetchState };

})();
