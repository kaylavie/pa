<?php
defined( 'ABSPATH' ) || exit;

class PA_Admin {

    public static function init() {
        add_action( 'admin_menu',            array( __CLASS__, 'register_menus' ) );
        add_action( 'admin_head',            array( __CLASS__, 'hide_report_menu_css' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_styles' ) );
    }

    public static function register_menus() {
        add_menu_page(
            'PressActivate',
            'PressActivate',
            'manage_options',
            'pressactivate',
            array( __CLASS__, 'page_sessions' ),
            'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><circle cx="10" cy="10" r="3" fill="#a7aaad"/><circle cx="10" cy="10" r="7" fill="none" stroke="#a7aaad" stroke-width="1.5"/></svg>' ),
            80
        );
        add_submenu_page( 'pressactivate', 'Sessions', 'Sessions', 'manage_options', 'pressactivate',          array( __CLASS__, 'page_sessions' ) );
        // Registered as a real submenu so WP's access-check authorizes it.
        // We hide the visible link via CSS in hide_report_menu_css() — modifying
        // the $submenu global causes "Sorry, you are not allowed to access this
        // page" because WP's authorization layer reads the same global.
        add_submenu_page( 'pressactivate', 'Report',   'Report',   'manage_options', 'pressactivate-report', array( __CLASS__, 'page_report' ) );
    }

    /**
     * Hides the "Report" entry from the visible admin sidebar without removing
     * the page from WP's allow-list. The submenu link is rendered with an
     * href containing the slug; an attribute selector targets it precisely.
     */
    public static function hide_report_menu_css() {
        echo '<style id="pa-hide-report-menu">' .
            '#toplevel_page_pressactivate .wp-submenu a[href*="page=pressactivate-report"]{display:none!important;}' .
            '</style>';
    }

    public static function enqueue_admin_styles( $hook ) {
        if ( strpos( $hook, 'pressactivate' ) === false && strpos( $hook, 'pa-' ) === false ) {
            return;
        }
        wp_enqueue_style(
            'pa-admin',
            PA_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            PA_VERSION
        );

        // Register (don't enqueue yet) the report-upload script. We register
        // here so any report page render can wp_localize_script() against it.
        // page_report() enqueues it when actually shown.
        wp_register_script(
            'pa-admin-report',
            PA_PLUGIN_URL . 'assets/js/admin-report.js',
            array(),
            PA_VERSION,
            true
        );
        if ( strpos( $hook, 'pressactivate-report' ) !== false ) {
            wp_enqueue_script( 'pa-admin-report' );
        }
    }

    // ── Pages ─────────────────────────────────────────────────────────────

    public static function page_sessions() {
        $sessions = PA_DB::get_sessions( array( 'limit' => 50 ) );
        ?>
        <div class="wrap pa-wrap">
            <div class="pa-header">
                <h1>PressActivate</h1>
                <p class="pa-sub">Onboarding &amp; activation analysis</p>
            </div>

            <?php if ( empty( $sessions ) ) : ?>
                <div class="pa-empty">
                    <p>No sessions recorded yet. Head to <a href="<?php echo esc_url( admin_url( 'admin.php?page=pa-user-test' ) ); ?>">User Test</a> to upload a blueprint and start your first session.</p>
                </div>
            <?php else : ?>
            <table class="pa-table">
                <thead>
                    <tr>
                        <th>Session</th>
                        <th>Started</th>
                        <th>Entry screen</th>
                        <th>Events</th>
                        <th>Markers</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $sessions as $s ) :
                    $report_url = admin_url( 'admin.php?page=pressactivate-report&session_id=' . urlencode( $s->session_id ) );
                    $status_class = 'pa-status-' . esc_attr( $s->status );
                ?>
                    <tr>
                        <td class="pa-mono"><?php echo esc_html( substr( $s->session_id, 0, 8 ) . '…' ); ?></td>
                        <td><?php echo esc_html( human_time_diff( strtotime( $s->started_at ), time() ) ) . ' ago'; ?></td>
                        <td class="pa-screen"><?php echo esc_html( $s->entry_screen ?: '—' ); ?></td>
                        <td><?php echo intval( $s->event_count ); ?></td>
                        <td><?php echo intval( $s->marker_count ); ?></td>
                        <td><span class="pa-badge <?php echo $status_class; ?>"><?php echo esc_html( $s->status ); ?></span></td>
                        <td><a href="<?php echo esc_url( $report_url ); ?>" class="pa-btn-sm">View report</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function page_report() {
        $session_id = sanitize_text_field( $_GET['session_id'] ?? '' );
        if ( ! $session_id ) {
            echo '<div class="wrap"><p>No session specified.</p></div>';
            return;
        }

        $session = PA_DB::get_session( $session_id );
        if ( ! $session ) {
            echo '<div class="wrap"><p>Session not found.</p></div>';
            return;
        }

        $report  = PA_DB::get_report( $session_id );
        $markers = PA_DB::get_session_markers( $session_id );
        $events  = PA_DB::get_session_events( $session_id );
        $issues  = $report ? json_decode( $report->issues, true ) : null;

        $upload_dir = wp_upload_dir();
        ?>
        <div class="wrap pa-wrap">
            <div class="pa-header">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=pressactivate' ) ); ?>" class="pa-back">← Sessions</a>
                <h1>Session Report</h1>
                <p class="pa-sub pa-mono"><?php echo esc_html( $session_id ); ?></p>
            </div>

            <div class="pa-report-meta">
                <div class="pa-meta-cell">
                    <span class="pa-meta-label">Entry screen</span>
                    <span class="pa-meta-val"><?php echo esc_html( $session->entry_screen ?: '—' ); ?></span>
                </div>
                <div class="pa-meta-cell">
                    <span class="pa-meta-label">Started</span>
                    <span class="pa-meta-val"><?php echo esc_html( $session->started_at ); ?></span>
                </div>
                <div class="pa-meta-cell">
                    <span class="pa-meta-label">Status</span>
                    <span class="pa-meta-val"><?php echo esc_html( $session->status ); ?></span>
                </div>
                <div class="pa-meta-cell">
                    <span class="pa-meta-label">Events</span>
                    <span class="pa-meta-val"><?php echo count( $events ); ?></span>
                </div>
                <div class="pa-meta-cell">
                    <span class="pa-meta-label">Markers</span>
                    <span class="pa-meta-val"><?php echo count( $markers ); ?></span>
                </div>
            </div>

            <?php
            $download_url = wp_nonce_url(
                admin_url( 'admin-post.php?action=pa_download_report&session_id=' . urlencode( $session_id ) ),
                'pa_download_report_' . $session_id
            );
            // Enqueue the client-side upload script with session-specific config.
            // The script (assets/js/admin-report.js) was registered by
            // enqueue_admin_styles when we detected this report screen; here we
            // just localize per-render data into window.PA_UPLOAD.
            wp_localize_script( 'pa-admin-report', 'PA_UPLOAD', array(
                'ajax_url'   => admin_url( 'admin-ajax.php' ),
                'api_base'   => defined( 'PA_API_BASE' ) ? PA_API_BASE : '',
                'session_id' => $session_id,
                'nonce'      => wp_create_nonce( 'pa_upload_report_' . $session_id ),
            ) );
            ?>

            <div class="pa-export-panel">
                <div class="pa-export-col">
                    <div class="pa-export-title">Raw report</div>
                    <p class="pa-export-desc">A full JSON dump of this session: events, markers, task results, and up to 20 screenshots. Conforms to <code>schema/report.v1.json</code>.</p>
                    <a href="<?php echo esc_url( $download_url ); ?>" class="pa-btn pa-btn-primary">Download JSON</a>
                </div>
                <div class="pa-export-col">
                    <div class="pa-export-title">Web report summary</div>
                    <p class="pa-export-desc">Generate a shareable, web-friendly report on pressactivate.com with a screenshot slideshow and tagged taxonomy issues. Anonymous uploads are limited to 3 per day.</p>
                    <button type="button" id="pa-generate-web-report" class="pa-btn pa-btn-secondary">Generate web report</button>
                    <div id="pa-upload-status" class="pa-upload-status" aria-live="polite"></div>
                </div>
            </div>

            <?php if ( $report && $report->status === 'complete' ) : ?>

                <?php if ( ! empty( $issues['summary'] ) ) : ?>
                <div class="pa-summary-block">
                    <div class="pa-summary-label">Diagnostic summary</div>
                    <p><?php echo esc_html( $issues['summary'] ); ?></p>
                    <?php if ( ! empty( $issues['activation_outcome'] ) ) : ?>
                    <span class="pa-badge pa-outcome-<?php echo esc_attr( $issues['activation_outcome'] ); ?>">
                        Outcome: <?php echo esc_html( $issues['activation_outcome'] ); ?>
                    </span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <?php if ( ! empty( $issues['issues'] ) ) : ?>
                <div class="pa-section-heading">Classified issues</div>
                <div class="pa-issues-list">
                    <?php foreach ( $issues['issues'] as $issue ) :
                        $sev = sanitize_key( $issue['severity'] ?? 'medium' );
                    ?>
                    <div class="pa-issue-card pa-sev-<?php echo esc_attr( $sev ); ?>">
                        <div class="pa-issue-header">
                            <span class="pa-issue-slug"><?php echo esc_html( $issue['issue'] ?? '' ); ?></span>
                            <span class="pa-sev-badge <?php echo esc_attr( $sev ); ?>"><?php echo esc_html( $sev ); ?></span>
                        </div>
                        <?php if ( ! empty( $issue['screen'] ) ) : ?>
                        <div class="pa-issue-screen"><?php echo esc_html( $issue['screen'] ); ?></div>
                        <?php endif; ?>
                        <div class="pa-issue-evidence"><?php echo esc_html( $issue['evidence'] ?? '' ); ?></div>
                        <?php if ( ! empty( $issue['marker_type'] ) && $issue['marker_type'] !== 'none' ) : ?>
                        <div class="pa-issue-marker">Marker: <strong><?php echo esc_html( $issue['marker_type'] ); ?></strong></div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

            <?php endif; // existing report data ?>

            <?php if ( ! empty( $markers ) ) : ?>
            <div class="pa-section-heading">Session markers</div>
            <div class="pa-markers-list">
                <?php foreach ( $markers as $m ) :
                    $ss_url = $m->screenshot_path
                        ? $upload_dir['baseurl'] . '/' . $m->screenshot_path
                        : '';
                ?>
                <div class="pa-marker-card pa-marker-<?php echo esc_attr( $m->marker_type ); ?>">
                    <div class="pa-marker-header">
                        <span class="pa-marker-type"><?php echo esc_html( strtoupper( $m->marker_type ) ); ?></span>
                        <span class="pa-marker-screen"><?php echo esc_html( $m->screen ?: '—' ); ?></span>
                    </div>
                    <?php if ( $m->annotation ) : ?>
                    <div class="pa-marker-annotation">"<?php echo esc_html( $m->annotation ); ?>"</div>
                    <?php endif; ?>
                    <?php if ( $ss_url ) : ?>
                    <div class="pa-screenshot-wrap">
                        <img src="<?php echo esc_url( $ss_url ); ?>" alt="Screenshot at <?php echo esc_attr( $m->marker_type ); ?> marker" />
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <div class="pa-section-heading">Event log <span class="pa-count"><?php echo count( $events ); ?></span></div>
            <div class="pa-event-log">
                <?php foreach ( array_slice( $events, -100 ) as $e ) :
                    $detail = trim( $e->element_text . ' ' . $e->aria_label );
                ?>
                <div class="pa-event-row">
                    <span class="pa-event-type"><?php echo esc_html( $e->event_type ); ?></span>
                    <span class="pa-event-screen"><?php echo esc_html( $e->screen ?: '—' ); ?></span>
                    <?php if ( $detail ) : ?>
                    <span class="pa-event-detail"><?php echo esc_html( substr( $detail, 0, 80 ) ); ?></span>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>

        </div>
        <?php
    }
}
