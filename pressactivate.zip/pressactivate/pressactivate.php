<?php
/**
 * Plugin Name: PressActivate
 * Plugin URI:  https://pressactivate.com
 * Description: User-testing tooling for WordPress. Upload a JSON test blueprint, run guided sessions, and capture behavioral evidence with a persistent floating control card.
 * Version:     1.2.0
 * Author:      PressActivate
 * License:     GPL-2.0+
 * Text Domain: pressactivate
 */

defined( 'ABSPATH' ) || exit;

define( 'PA_VERSION',     '1.2.0' );
define( 'PA_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'PA_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'PA_PLUGIN_FILE', __FILE__ );

require_once PA_PLUGIN_DIR . 'includes/class-pa-db.php';
require_once PA_PLUGIN_DIR . 'includes/class-pa-session.php';
require_once PA_PLUGIN_DIR . 'includes/class-pa-events.php';
require_once PA_PLUGIN_DIR . 'includes/class-pa-screenshots.php';
require_once PA_PLUGIN_DIR . 'includes/class-pa-test-runner.php';
require_once PA_PLUGIN_DIR . 'includes/class-pa-report.php';
require_once PA_PLUGIN_DIR . 'admin/class-pa-admin.php';

register_activation_hook( __FILE__, array( 'PA_DB', 'install' ) );
register_activation_hook( __FILE__, array( 'PA_Test_Runner', 'on_activate' ) );
register_deactivation_hook( __FILE__, array( 'PA_DB', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'PA_Core', 'init' ) );

class PA_Core {
    public static function init() {
        PA_Session::init();
        PA_Events::init();
        PA_Screenshots::init();
        PA_Admin::init();
        PA_Test_Runner::init();
        PA_Report::init();
    }
}
